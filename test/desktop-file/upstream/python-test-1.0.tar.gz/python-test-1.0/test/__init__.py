import os
import sys

class Test (object):

    def __init__(self):
        print("Hallo World")


