# $Id: extconf.rb,v 1.1 2003/10/12 06:10:49 aamine Exp $

require 'mkmf'
create_makefile 'racc/cparse'
