g <-
function(x,y) x-y

