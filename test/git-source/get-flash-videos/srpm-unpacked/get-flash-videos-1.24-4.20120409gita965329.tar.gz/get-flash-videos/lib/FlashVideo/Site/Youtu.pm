# Part of get-flash-videos. See get_flash_videos for copyright.
package FlashVideo::Site::Youtu;

# youtu.be is just an alias for youtube; everything else is handled further up
use base 'FlashVideo::Site::Youtube';

1;
