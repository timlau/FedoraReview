#include "MT_Vector4.h"

#ifndef GEN_INLINED
#include "MT_Vector4.inl"
#endif
