#include "MT_Point2.h"

#ifndef GEN_INLINED
#include "MT_Point2.inl"
#endif
