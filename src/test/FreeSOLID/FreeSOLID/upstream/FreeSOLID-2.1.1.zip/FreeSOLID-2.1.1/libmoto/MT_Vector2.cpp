#include "MT_Vector2.h"

#ifndef GEN_INLINED
#include "MT_Vector2.inl"
#endif
