#ifndef GEN_OPTIMIZE_H
#define GEN_OPTIMIZE_H

#ifdef GEN_INLINED
#define GEN_INLINE inline
#else
#define GEN_INLINE
#endif 

#endif
